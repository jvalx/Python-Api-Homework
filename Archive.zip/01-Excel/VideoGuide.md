# Unit 1 - Excel

## Key activities from the week

### Lesson - Apples and Oranges

Use Excel functions to compare data from two different sheets.
[Watch the Video](https://youtu.be/Fuo4us0EtfU)

### Lesson - Product Pivot

Use lookups to create a pivot table that visualizes the cost of recent orders of a small electronics company.
[Watch the Video](https://youtu.be/1RfC0rUW1xw)

### Lesson - Game Sales

Create a series of scatter plots which will compare video game sales across regions.
[Watch the Video](https://youtu.be/Aj9Na_PBB3E)

- - - 

### Copyright

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.
