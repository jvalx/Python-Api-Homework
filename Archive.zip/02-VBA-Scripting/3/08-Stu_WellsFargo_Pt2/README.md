# Wells Fargo - Part II

* In this second part of the mini project project, you will be combining all of your previous Excel sheets into one massive table on a new sheet.

**Instructions**

* Loop through every worksheet and select the state contents.

* Copy the state contents and paste it into the Combined_Data tab
