# United States Population Growth Part 3

The Grand conclusion! We will now place everything into one giant script!

## Instructions

* Delete the results from everything done in steps one and two.

* Combine our scripts from parts one and two.

* Make adjustments where needed and run the script.

* You results should be exactly the same as running them individually.
