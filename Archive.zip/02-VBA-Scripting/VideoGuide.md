# Unit 2 - VBA Scripting

## Key activities from the week

### Lesson - Choose Your Story

Create buttons attached to VBA macros that will determine your player's destiny!
[Watch the Video](https://youtu.be/EqV1LQgofP4)

### Lesson - Hornets' Nest

Create a VBA script to handle the growing hornet infestation in your spreadsheet.
[Watch the Video](https://youtu.be/0f-M3cKzWMs)

### Lesson - Credit Card Checker

Create a credit card checker with VBA that identifies different credit cards, pops open a message box, and sums the total spent with each credit card. [Watch the Video](https://youtu.be/xkRl14pHLBU)

- - - 

### Copyright

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.
